// Global state
let currentLanguage = 'es';
let currentTheme = 'light';
let currentSlide = 0;
let newsData = [];
let videosData = [];

// News data structure
const sampleNewsData = {
    trends: [
        {
            id: 1,
            title: "GitHub Copilot X revoluciona el desarrollo con IA conversacional",
            excerpt: "La nueva versión de GitHub Copilot integra capacidades de chat y análisis de código en tiempo real, transformando la experiencia de programación.",
            content: `<p>GitHub ha lanzado oficialmente Copilot X, una evolución revolucionaria de su asistente de programación basado en inteligencia artificial. Esta nueva versión no solo sugiere código, sino que mantiene conversaciones contextuales con los desarrolladores.</p>

<h2>Características principales</h2>

<p>Copilot X introduce varias funcionalidades innovadoras que están cambiando la forma en que los desarrolladores abordan la programación:</p>

<blockquote>"Es como tener un compañero de programación senior disponible 24/7" - Sarah Chen, Desarrolladora Principal en Microsoft</blockquote>

<h3>Chat Inteligente</h3>
<p>La función de chat permite a los desarrolladores hacer preguntas complejas sobre su código, solicitar explicaciones de funciones específicas y obtener sugerencias de refactorización en lenguaje natural.</p>

<h3>Análisis Contextual</h3>
<p>El sistema analiza todo el contexto del proyecto, incluyendo documentación, comentarios y estructura de archivos, para proporcionar sugerencias más precisas y relevantes.</p>

<p>Los primeros usuarios reportan un aumento del 40% en productividad, especialmente en tareas de depuración y optimización de código.</p>`,
            category: "Tendencias",
            author: "María González",
            date: "2024-11-15",
            image: "./assets/news-copilot-x.png",
            tags: ["GitHub", "IA", "Productividad", "Desarrollo"]
        },
        {
            id: 2,
            title: "OpenAI Code Interpreter cambia las reglas del juego en programación",
            excerpt: "La nueva herramienta de OpenAI permite ejecutar código en tiempo real y generar visualizaciones complejas directamente desde el chat.",
            content: `<p>OpenAI ha introducido Code Interpreter, una funcionalidad que permite a ChatGPT ejecutar código Python en tiempo real, analizar datos y crear visualizaciones complejas sin necesidad de herramientas externas.</p>

<h2>Capacidades revolucionarias</h2>

<p>Code Interpreter no es solo un ejecutor de código, sino una herramienta completa de análisis y desarrollo:</p>

<h3>Ejecución en tiempo real</h3>
<p>Los desarrolladores pueden escribir código Python y ver los resultados inmediatamente, incluyendo gráficos, análisis de datos y procesamiento de archivos.</p>

<h3>Análisis de datos automatizado</h3>
<p>La herramienta puede procesar archivos CSV, Excel, y otros formatos de datos, generando insights automáticamente y creando visualizaciones relevantes.</p>

<blockquote>"Es como tener un científico de datos y un desarrollador trabajando juntos en cada consulta" - Dr. Alex Kumar, Investigador en IA</blockquote>

<p>Esta innovación está democratizando el acceso a análisis de datos complejos y programación avanzada.</p>`,
            category: "Tendencias",
            author: "Carlos Ruiz",
            date: "2024-11-14",
            image: "./assets/news-openai-code.png",
            tags: ["OpenAI", "Python", "Análisis", "Visualización"]
        },
        {
            id: 3,
            title: "Google Bard integra programación colaborativa con gemelos digitales",
            excerpt: "La última actualización de Bard permite crear 'gemelos digitales' de desarrolladores para proyectos colaborativos distribuidos.",
            content: `<p>Google ha anunciado una funcionalidad experimental en Bard que permite crear "gemelos digitales" de desarrolladores, facilitando la colaboración en proyectos de programación distribuidos.</p>

<h2>Colaboración del futuro</h2>

<p>Los gemelos digitales capturan el estilo de programación, preferencias y conocimientos específicos de cada desarrollador:</p>

<h3>Replicación de estilo</h3>
<p>El sistema aprende patrones de codificación individuales, incluyendo convenciones de nomenclatura, estructuras preferidas y enfoques de resolución de problemas.</p>

<h3>Colaboración asíncrona</h3>
<p>Los equipos pueden continuar trabajando incluso cuando algunos miembros no están disponibles, utilizando sus gemelos digitales para mantener la consistencia del proyecto.</p>

<blockquote>"Es fascinante ver cómo la IA puede capturar no solo lo que programamos, sino cómo lo programamos" - Jennifer Walsh, Tech Lead en Spotify</blockquote>

<p>Esta tecnología promete revolucionar la colaboración remota en el desarrollo de software.</p>`,
            category: "Tendencias",
            author: "Ana Torres",
            date: "2024-11-13",
            image: "./assets/news-bard-collaboration.png",
            tags: ["Google", "Bard", "Colaboración", "Equipos"]
        }
    ],
    interviews: [
        {
            id: 4,
            title: "Entrevista exclusiva: Jensen Huang sobre el futuro de la programación con IA",
            excerpt: "El CEO de NVIDIA comparte su visión sobre cómo la IA transformará completamente el desarrollo de software en los próximos 5 años.",
            content: `<p>En una entrevista exclusiva, Jensen Huang, CEO de NVIDIA, comparte su perspectiva sobre la revolución que la inteligencia artificial está generando en el desarrollo de software.</p>

<h2>La visión de NVIDIA</h2>

<blockquote>"Estamos en el amanecer de una nueva era donde la programación se convierte en una conversación natural entre humanos y máquinas" - Jensen Huang</blockquote>

<h3>El papel de los aceleradores</h3>
<p><strong>Pregunta:</strong> ¿Cómo ve el rol del hardware especializado en el desarrollo asistido por IA?</p>

<p><strong>Huang:</strong> Los aceleradores no solo hacen que la IA sea más rápida, sino que habilitan nuevas formas de interacción. Con nuestras GPUs H100 y A100, los desarrolladores pueden entrenar modelos personalizados que entienden su código específico.</p>

<h3>Democratización de la programación</h3>
<p><strong>Pregunta:</strong> ¿Cree que la IA hará la programación más accesible?</p>

<p><strong>Huang:</strong> Absolutamente. En 5 años, cualquier persona podrá crear aplicaciones complejas simplemente describiendo lo que necesita. Pero los programadores expertos seguirán siendo cruciales para sistemas críticos y arquitecturas avanzadas.</p>

<h3>Predicciones para 2025-2030</h3>
<p>Huang predice que veremos IDE completamente conversacionales, donde el código se genera mediante diálogo natural y se optimiza automáticamente para diferentes arquitecturas de hardware.</p>`,
            category: "Entrevistas",
            author: "María González",
            date: "2024-11-12",
            image: "./assets/interview-jensen-huang.png",
            tags: ["NVIDIA", "CEO", "Futuro", "Hardware"]
        },
        {
            id: 5,
            title: "Caso de éxito: Startup reduce tiempo de desarrollo 80% con Claude-3",
            excerpt: "TechFlow, una startup de fintech, comparte cómo implementaron Claude-3 para acelerar dramáticamente su desarrollo de productos.",
            content: `<p>TechFlow, una prometedora startup de tecnología financiera, ha logrado reducir su tiempo de desarrollo en un 80% mediante la implementación estratégica de Claude-3 de Anthropic en su flujo de trabajo.</p>

<h2>El desafío inicial</h2>

<p>Con un equipo de solo 4 desarrolladores, TechFlow necesitaba crear una plataforma completa de gestión financiera en tiempo récord para competir con grandes players del mercado.</p>

<blockquote>"Necesitábamos la productividad de un equipo de 20 personas con solo 4 desarrolladores. Claude-3 nos dio exactamente eso" - Maria Santos, CTO de TechFlow</blockquote>

<h3>Implementación estratégica</h3>

<p><strong>Generación de código base:</strong> Utilizaron Claude-3 para generar la arquitectura inicial del backend, incluyendo APIs REST, autenticación y manejo de bases de datos.</p>

<p><strong>Testing automatizado:</strong> El sistema genera automáticamente casos de prueba comprensivos basados en los requisitos funcionales.</p>

<p><strong>Documentación en vivo:</strong> Claude-3 mantiene la documentación actualizada automáticamente con cada cambio en el código.</p>

<h2>Resultados impresionantes</h2>

<ul>
<li>Reducción del 80% en tiempo de desarrollo</li>
<li>40% menos bugs en producción</li>
<li>Documentación 100% actualizada</li>
<li>Cobertura de tests del 95%</li>
</ul>

<p>La startup logró lanzar su MVP en 3 meses en lugar de los 15 meses inicialmente proyectados.</p>`,
            category: "Entrevistas",
            author: "Carlos Ruiz",
            date: "2024-11-11",
            image: "./assets/case-study-techflow.png",
            tags: ["Startup", "Claude-3", "Fintech", "Productividad"]
        }
    ],
    tools: [
        {
            id: 6,
            title: "Cursor AI: El editor que está conquistando a los desarrolladores",
            excerpt: "Análisis completo del nuevo editor de código que promete revolucionar la experiencia de desarrollo con IA integrada nativamente.",
            content: `<p>Cursor AI ha emergido como el editor de código más innovador de 2024, integrando capacidades de inteligencia artificial directamente en el flujo de desarrollo sin interrupciones.</p>

<h2>Características destacadas</h2>

<h3>IA integrada nativamente</h3>
<p>A diferencia de las extensiones tradicionales, Cursor AI tiene la inteligencia artificial integrada en su núcleo, permitiendo sugerencias contextuales instantáneas y comprensión profunda del código.</p>

<blockquote>"Es como si el editor pudiera leer mi mente y anticipar exactamente lo que necesito escribir" - David Kim, Senior Developer en Stripe</blockquote>

<h3>Modo Composer</h3>
<p>Esta funcionalidad permite generar archivos completos o hacer refactorizaciones masivas simplemente describiendo los cambios deseados en lenguaje natural.</p>

<h3>Chat contextual</h3>
<p>El chat integrado entiende todo el contexto del proyecto, incluyendo bases de datos, APIs externas y documentación, para proporcionar respuestas precisas.</p>

<h2>Comparativa con la competencia</h2>

<table>
<tr><th>Característica</th><th>Cursor</th><th>VS Code + Copilot</th><th>JetBrains + AI</th></tr>
<tr><td>Velocidad de sugerencias</td><td>Instantánea</td><td>1-2 segundos</td><td>2-3 segundos</td></tr>
<tr><td>Comprensión contextual</td><td>Excelente</td><td>Buena</td><td>Buena</td></tr>
<tr><td>Refactoring masivo</td><td>Sí</td><td>Limitado</td><td>Limitado</td></tr>
</table>

<p>Los desarrolladores que han migrado a Cursor reportan un aumento promedio del 50% en velocidad de desarrollo.</p>`,
            category: "Herramientas",
            author: "Ana Torres",
            date: "2024-11-10",
            image: "./assets/tool-cursor-ai.png",
            tags: ["Editor", "IDE", "Productividad", "Desarrollo"]
        },
        {
            id: 7,
            title: "V0 de Vercel: Generación de UI con IA llega a su madurez",
            excerpt: "La plataforma de Vercel para generar interfaces de usuario mediante prompts naturales alcanza niveles de calidad profesional.",
            content: `<p>V0 de Vercel ha alcanzado un nivel de madurez que permite generar interfaces de usuario de calidad profesional mediante simples descripciones en lenguaje natural.</p>

<h2>Evolución significativa</h2>

<p>Desde su lanzamiento beta, V0 ha mejorado dramáticamente en la comprensión de requerimientos de diseño y la generación de código React optimizado.</p>

<h3>Generación inteligente</h3>
<p>El sistema ahora genera no solo HTML y CSS, sino componentes React completos con hooks, estado local y integración con APIs.</p>

<blockquote>"V0 ha reducido nuestro tiempo de prototipado de días a minutos" - Lisa Chen, Product Designer en Airbnb</blockquote>

<h3>Estilos coherentes</h3>
<p>La plataforma mantiene consistencia visual automáticamente, aplicando principios de design systems y mejores prácticas de UX.</p>

<h2>Casos de uso destacados</h2>

<p><strong>Dashboards administrativos:</strong> Genera paneles complejos con gráficos, tablas y filtros en minutos.</p>

<p><strong>Landing pages:</strong> Crea páginas de aterrizaje optimizadas para conversión con secciones hero, testimonios y CTAs.</p>

<p><strong>E-commerce:</strong> Genera catálogos de productos, carritos de compra y formularios de checkout completos.</p>

<h3>Integración con el ecosistema</h3>
<p>V0 se integra perfectamente con Next.js, Tailwind CSS y otras herramientas del stack moderno de desarrollo web.</p>

<p>Los desarrolladores reportan que V0 es especialmente útil para prototipado rápido y generación de componentes base que luego personalizan según necesidades específicas.</p>`,
            category: "Herramientas",
            author: "María González",
            date: "2024-11-09",
            image: "./assets/tool-v0-vercel.png",
            tags: ["Vercel", "UI", "React", "Prototipado"]
        }
    ],
    impact: [
        {
            id: 8,
            title: "Estudio revela: 73% de desarrolladores ya usa IA en su trabajo diario",
            excerpt: "Nueva investigación de Stack Overflow muestra la adopción masiva de herramientas de IA en el desarrollo de software y su impacto en la productividad.",
            content: `<p>El último Developer Survey de Stack Overflow revela que 73% de los desarrolladores profesionales ya incorporan herramientas de inteligencia artificial en su trabajo diario, marcando un cambio fundamental en la industria.</p>

<h2>Datos clave del estudio</h2>

<p>La encuesta, realizada a más de 87,000 desarrolladores a nivel mundial, muestra tendencias claras sobre la adopción de IA:</p>

<h3>Adopción por experiencia</h3>
<ul>
<li>Desarrolladores junior (1-3 años): 89% utiliza IA</li>
<li>Desarrolladores semi-senior (4-7 años): 76% utiliza IA</li>
<li>Desarrolladores senior (8+ años): 58% utiliza IA</li>
</ul>

<blockquote>"Los desarrolladores más jóvenes están adoptando la IA como una extensión natural de su flujo de trabajo" - Prashanth Chandrasekar, CEO de Stack Overflow</blockquote>

<h3>Herramientas más utilizadas</h3>
<p>1. GitHub Copilot - 45% de adopción<br>
2. ChatGPT/GPT-4 - 38% de adopción<br>
3. Claude - 12% de adopción<br>
4. Cursor AI - 8% de adopción</p>

<h2>Impacto en productividad</h2>

<p>Los desarrolladores que usan IA reportan:</p>
<ul>
<li>35% menos tiempo en debugging</li>
<li>40% más rapidez en prototipado</li>
<li>25% mejora en calidad de código</li>
<li>50% menos tiempo en tareas repetitivas</li>
</ul>

<h3>Preocupaciones y desafíos</h3>
<p>A pesar de los beneficios, 42% de los encuestados expresan preocupaciones sobre la dependencia excesiva de IA y 31% sobre la calidad del código generado automáticamente.</p>

<p>El estudio concluye que la IA se ha convertido en una herramienta esencial, pero la experiencia humana sigue siendo fundamental para arquitectura, decisiones críticas y validación de soluciones.</p>`,
            category: "Impacto",
            author: "Carlos Ruiz",
            date: "2024-11-08",
            image: "./assets/study-ai-adoption.png",
            tags: ["Estudio", "Adopción", "Productividad", "Industria"]
        },
        {
            id: 9,
            title: "Universidades adaptan curricula: Programación con IA como materia obligatoria",
            excerpt: "Las principales universidades tecnológicas del mundo están reestructurando sus programas para incluir programación asistida por IA como competencia fundamental.",
            content: `<p>Las universidades más prestigiosas del mundo están revolucionando sus curricula de ciencias de la computación para incluir programación asistida por IA como una competencia fundamental, no opcional.</p>

<h2>Cambio paradigmático en educación</h2>

<p>MIT, Stanford, Carnegie Mellon y otras 47 universidades han anunciado modificaciones significativas en sus programas académicos para preparar a los estudiantes para la realidad de la industria.</p>

<blockquote>"No enseñar programación con IA sería como enseñar matemáticas sin calculadora en pleno siglo XXI" - Dr. Elena Vasquez, Decana de Computer Science en MIT</blockquote>

<h3>Nuevas materias implementadas</h3>

<p><strong>Programación Colaborativa con IA:</strong> Enseña cómo trabajar efectivamente con asistentes de código y optimizar prompts para desarrollo.</p>

<p><strong>Ética en IA para Desarrolladores:</strong> Aborda responsabilidades éticas, sesgo algorítmico y transparencia en sistemas automatizados.</p>

<p><strong>Arquitectura de Sistemas IA-First:</strong> Diseño de sistemas que aprovechan IA desde su concepción.</p>

<h2>Reacción de la industria</h2>

<p>Las grandes empresas tecnológicas han respondido positivamente a estos cambios:</p>

<p><strong>Google:</strong> Ha aumentado su programa de becas para universidades que implementen curricula de IA.</p>

<p><strong>Microsoft:</strong> Ofrece acceso gratuito a Azure OpenAI Service para proyectos estudiantiles.</p>

<p><strong>Meta:</strong> Ha lanzado un programa de mentorías para estudiantes especializados en desarrollo con IA.</p>

<h3>Impacto en empleabilidad</h3>
<p>Los primeros graduados de estos programas muestran tasas de empleabilidad 40% superiores y salarios iniciales 25% más altos que sus pares de programas tradicionales.</p>

<p>Esta transformación educativa refleja la nueva realidad donde la colaboración entre humanos e IA define el futuro del desarrollo de software.</p>`,
            category: "Impacto",
            author: "Ana Torres",
            date: "2024-11-07",
            image: "./assets/education-ai-curriculum.png",
            tags: ["Educación", "Universidad", "Curriculum", "Futuro"]
        }
    ]
};

const sampleVideosData = [
    {
        id: 1,
        title: "GitHub Copilot X: Demo completa de las nuevas funcionalidades",
        description: "Exploración detallada de las capacidades de chat, análisis contextual y generación de documentación de GitHub Copilot X.",
        thumbnail: "./assets/video-copilot-demo.png",
        duration: "15:32",
        views: "125K",
        date: "2024-11-15",
        category: "Demo"
    },
    {
        id: 2,
        title: "Entrevista: CEO de Anthropic habla sobre el futuro de Claude",
        description: "Conversación exclusiva con Dario Amodei sobre los planes de desarrollo de Claude y su impacto en la programación.",
        thumbnail: "./assets/video-anthropic-interview.png",
        duration: "28:45",
        views: "89K",
        date: "2024-11-12",
        category: "Entrevista"
    },
    {
        id: 3,
        title: "Cursor vs VS Code: Comparativa completa para desarrolladores",
        description: "Análisis exhaustivo comparando características, rendimiento y experiencia de usuario entre Cursor AI y VS Code.",
        thumbnail: "./assets/video-cursor-vs-vscode.png",
        duration: "22:18",
        views: "203K",
        date: "2024-11-10",
        category: "Comparativa"
    },
    {
        id: 4,
        title: "Construyendo una app completa solo con V0 y prompts",
        description: "Tutorial paso a paso creando una aplicación de gestión de tareas utilizando únicamente V0 de Vercel y prompts naturales.",
        thumbnail: "./assets/video-v0-tutorial.png",
        duration: "35:20",
        views: "156K",
        date: "2024-11-08",
        category: "Tutorial"
    },
    {
        id: 5,
        title: "Panel: ¿Reemplazará la IA a los programadores?",
        description: "Debate entre expertos de la industria sobre el futuro del desarrollo de software en la era de la inteligencia artificial.",
        thumbnail: "./assets/video-panel-future.png",
        duration: "42:15",
        views: "312K",
        date: "2024-11-05",
        category: "Panel"
    },
    {
        id: 6,
        title: "Configurando el IDE perfecto para Vibe Coding en 2024",
        description: "Guía completa para configurar tu entorno de desarrollo con las mejores herramientas de IA disponibles.",
        thumbnail: "./assets/video-ide-setup.png",
        duration: "18:30",
        views: "94K",
        date: "2024-11-03",
        category: "Tutorial"
    }
];

// DOM elements
const elements = {
    navLinks: document.querySelectorAll('.nav-link'),
    sections: document.querySelectorAll('.section'),
    searchBtn: document.getElementById('search-btn'),
    searchOverlay: document.getElementById('search-overlay'),
    searchClose: document.getElementById('search-close'),
    searchInput: document.getElementById('search-input'),
    searchSubmit: document.getElementById('search-submit'),
    themeToggle: document.getElementById('theme-toggle'),
    langToggle: document.getElementById('lang-toggle'),
    navToggle: document.getElementById('nav-toggle'),
    navMenu: document.getElementById('nav-menu'),
    carouselSlides: document.querySelectorAll('.carousel-slide'),
    carouselIndicators: document.querySelectorAll('.indicator'),
    prevBtn: document.getElementById('prev-btn'),
    nextBtn: document.getElementById('next-btn'),
    newsCards: document.getElementById('news-cards'),
    videosGrid: document.getElementById('videos-grid'),
    newsletterPopup: document.getElementById('newsletter-popup'),
    popupClose: document.getElementById('popup-close'),
    articleModal: document.getElementById('article-modal'),
    modalClose: document.getElementById('modal-close'),
    modalBody: document.getElementById('modal-body'),
    contactForm: document.getElementById('contact-form'),
    newsletterForm: document.getElementById('newsletter-form')
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadInitialContent();
    startCarousel();
    showNewsletterPopup();
});

function initializeApp() {
    // Set initial theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    
    // Set initial language
    const savedLanguage = localStorage.getItem('language') || 'es';
    setLanguage(savedLanguage);
    
    // Combine all news data
    newsData = [
        ...sampleNewsData.trends,
        ...sampleNewsData.interviews,
        ...sampleNewsData.tools,
        ...sampleNewsData.impact
    ];
    
    videosData = sampleVideosData;
}

function setupEventListeners() {
    // Navigation
    elements.navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSection = link.getAttribute('data-section');
            navigateToSection(targetSection);
        });
    });
    
    // Mobile menu toggle
    if (elements.navToggle && elements.navMenu) {
        elements.navToggle.addEventListener('click', () => {
            elements.navMenu.classList.toggle('active');
        });
    }
    
    // Search functionality
    if (elements.searchBtn) {
        elements.searchBtn.addEventListener('click', () => {
            elements.searchOverlay.classList.add('active');
            elements.searchInput.focus();
        });
    }
    
    if (elements.searchClose) {
        elements.searchClose.addEventListener('click', () => {
            elements.searchOverlay.classList.remove('active');
        });
    }
    
    if (elements.searchSubmit) {
        elements.searchSubmit.addEventListener('click', performSearch);
    }
    
    if (elements.searchInput) {
        elements.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
    
    // Theme toggle
    if (elements.themeToggle) {
        elements.themeToggle.addEventListener('click', toggleTheme);
    }
    
    // Language toggle
    if (elements.langToggle) {
        elements.langToggle.addEventListener('click', toggleLanguage);
    }
    
    // Carousel controls
    if (elements.prevBtn && elements.nextBtn) {
        elements.prevBtn.addEventListener('click', () => changeSlide(-1));
        elements.nextBtn.addEventListener('click', () => changeSlide(1));
    }
    
    // Carousel indicators
    elements.carouselIndicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => goToSlide(index));
    });
    
    // Tab functionality
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const tabGroup = e.target.closest('.grid-tabs, .tab-group');
            const tabs = tabGroup.querySelectorAll('.tab-btn');
            const targetTab = e.target.getAttribute('data-tab');
            
            tabs.forEach(tab => tab.classList.remove('active'));
            e.target.classList.add('active');
            
            filterContent(targetTab);
        });
    });
    
    // Newsletter popup
    if (elements.popupClose) {
        elements.popupClose.addEventListener('click', () => {
            elements.newsletterPopup.classList.remove('active');
            localStorage.setItem('newsletter-shown', 'true');
        });
    }
    
    // Modal close
    if (elements.modalClose) {
        elements.modalClose.addEventListener('click', () => {
            elements.articleModal.classList.remove('active');
        });
    }
    
    // Close modals on overlay click
    [elements.searchOverlay, elements.newsletterPopup, elements.articleModal].forEach(modal => {
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            });
        }
    });
    
    // Forms
    if (elements.contactForm) {
        elements.contactForm.addEventListener('submit', handleContactForm);
    }
    
    if (elements.newsletterForm) {
        elements.newsletterForm.addEventListener('submit', handleNewsletterForm);
    }
    
    // Footer newsletter
    const footerNewsletter = document.querySelector('.footer-newsletter');
    if (footerNewsletter) {
        footerNewsletter.addEventListener('submit', handleNewsletterForm);
    }
}

function navigateToSection(sectionId) {
    // Update navigation
    elements.navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-section') === sectionId) {
            link.classList.add('active');
        }
    });
    
    // Update sections
    elements.sections.forEach(section => {
        section.classList.remove('active');
        if (section.id === sectionId) {
            section.classList.add('active');
        }
    });
    
    // Load section-specific content
    loadSectionContent(sectionId);
    
    // Close mobile menu
    if (elements.navMenu) {
        elements.navMenu.classList.remove('active');
    }
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function loadSectionContent(sectionId) {
    switch(sectionId) {
        case 'trends':
            loadCategoryContent('trends');
            break;
        case 'interviews':
            loadCategoryContent('interviews');
            break;
        case 'tools':
            loadCategoryContent('tools');
            break;
        case 'impact':
            loadCategoryContent('impact');
            break;
        case 'videos':
            loadVideosContent();
            break;
        default:
            // Home section content is loaded by default
            break;
    }
}

function loadCategoryContent(category) {
    const contentContainer = document.getElementById(`${category}-content`);
    if (!contentContainer) return;
    
    const categoryData = sampleNewsData[category] || [];
    
    contentContainer.innerHTML = categoryData.map(article => `
        <article class="news-card fade-in-up" onclick="openArticle(${article.id})">
            <div class="card-image">
                <img src="${article.image}" alt="${article.title}" loading="lazy">
                <span class="card-category">${article.category}</span>
            </div>
            <div class="card-content">
                <h2 class="card-title">${article.title}</h2>
                <p class="card-excerpt">${article.excerpt}</p>
                <div class="card-meta">
                    <span class="card-author">Por ${article.author}</span>
                    <time class="card-date">${formatDate(article.date)}</time>
                </div>
            </div>
        </article>
    `).join('');
}

function loadInitialContent() {
    loadNewsCards();
    loadVideosContent();
}

function loadNewsCards() {
    if (!elements.newsCards) return;
    
    // Get latest 6 articles
    const latestNews = newsData
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 6);
    
    elements.newsCards.innerHTML = latestNews.map(article => `
        <article class="news-card fade-in-up" onclick="openArticle(${article.id})">
            <div class="card-image">
                <img src="${article.image}" alt="${article.title}" loading="lazy">
                <span class="card-category">${article.category}</span>
            </div>
            <div class="card-content">
                <h2 class="card-title">${article.title}</h2>
                <p class="card-excerpt">${article.excerpt}</p>
                <div class="card-meta">
                    <span class="card-author">Por ${article.author}</span>
                    <time class="card-date">${formatDate(article.date)}</time>
                </div>
            </div>
        </article>
    `).join('');
}

function loadVideosContent() {
    if (!elements.videosGrid) return;
    
    elements.videosGrid.innerHTML = videosData.map(video => `
        <div class="video-card fade-in-up" onclick="playVideo(${video.id})">
            <div class="video-thumbnail">
                <img src="${video.thumbnail}" alt="${video.title}" loading="lazy">
                <div class="play-button">
                    <i class="fas fa-play"></i>
                </div>
            </div>
            <div class="video-info">
                <h3 class="video-title">${video.title}</h3>
                <p class="video-description">${video.description}</p>
                <div class="video-meta">
                    <span class="video-duration">${video.duration}</span>
                    <span class="video-views">${video.views} visualizaciones</span>
                </div>
            </div>
        </div>
    `).join('');
}

function startCarousel() {
    setInterval(() => {
        currentSlide = (currentSlide + 1) % elements.carouselSlides.length;
        updateCarousel();
    }, 5000);
}

function changeSlide(direction) {
    currentSlide += direction;
    if (currentSlide >= elements.carouselSlides.length) currentSlide = 0;
    if (currentSlide < 0) currentSlide = elements.carouselSlides.length - 1;
    updateCarousel();
}

function goToSlide(index) {
    currentSlide = index;
    updateCarousel();
}

function updateCarousel() {
    elements.carouselSlides.forEach((slide, index) => {
        slide.classList.toggle('active', index === currentSlide);
    });
    
    elements.carouselIndicators.forEach((indicator, index) => {
        indicator.classList.toggle('active', index === currentSlide);
    });
}

function performSearch() {
    const query = elements.searchInput.value.toLowerCase().trim();
    const categoryFilter = document.getElementById('category-filter').value;
    const dateFilter = document.getElementById('date-filter').value;
    
    if (!query && !categoryFilter && !dateFilter) return;
    
    let results = newsData.filter(article => {
        const matchesQuery = !query || 
            article.title.toLowerCase().includes(query) ||
            article.excerpt.toLowerCase().includes(query) ||
            article.content.toLowerCase().includes(query) ||
            article.tags.some(tag => tag.toLowerCase().includes(query));
        
        const matchesCategory = !categoryFilter || 
            article.category.toLowerCase() === categoryFilter;
        
        const matchesDate = !dateFilter || 
            article.date === dateFilter;
        
        return matchesQuery && matchesCategory && matchesDate;
    });
    
    displaySearchResults(results, query);
    elements.searchOverlay.classList.remove('active');
}

function displaySearchResults(results, query) {
    // Navigate to home section and show results
    navigateToSection('home');
    
    // Update grid header
    const gridHeader = document.querySelector('.grid-header h2');
    if (gridHeader) {
        gridHeader.textContent = `Resultados de búsqueda: "${query}" (${results.length})`;
    }
    
    // Display results
    if (results.length === 0) {
        elements.newsCards.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
                <h3>No se encontraron resultados</h3>
                <p>Intenta con otros términos de búsqueda o filtra por categoría.</p>
            </div>
        `;
    } else {
        elements.newsCards.innerHTML = results.map(article => `
            <article class="news-card fade-in-up" onclick="openArticle(${article.id})">
                <div class="card-image">
                    <img src="${article.image}" alt="${article.title}" loading="lazy">
                    <span class="card-category">${article.category}</span>
                </div>
                <div class="card-content">
                    <h2 class="card-title">${article.title}</h2>
                    <p class="card-excerpt">${article.excerpt}</p>
                    <div class="card-meta">
                        <span class="card-author">Por ${article.author}</span>
                        <time class="card-date">${formatDate(article.date)}</time>
                    </div>
                </div>
            </article>
        `).join('');
    }
}

function filterContent(filter) {
    let filteredNews;
    
    switch(filter) {
        case 'trending':
            // Sort by a combination of recency and artificial "popularity"
            filteredNews = newsData
                .sort((a, b) => {
                    const aScore = new Date(a.date).getTime() + Math.random() * 1000000;
                    const bScore = new Date(b.date).getTime() + Math.random() * 1000000;
                    return bScore - aScore;
                })
                .slice(0, 6);
            break;
        case 'recent':
            filteredNews = newsData
                .sort((a, b) => new Date(b.date) - new Date(a.date))
                .slice(0, 6);
            break;
        default:
            filteredNews = newsData
                .sort((a, b) => new Date(b.date) - new Date(a.date))
                .slice(0, 6);
    }
    
    elements.newsCards.innerHTML = filteredNews.map(article => `
        <article class="news-card fade-in-up" onclick="openArticle(${article.id})">
            <div class="card-image">
                <img src="${article.image}" alt="${article.title}" loading="lazy">
                <span class="card-category">${article.category}</span>
            </div>
            <div class="card-content">
                <h2 class="card-title">${article.title}</h2>
                <p class="card-excerpt">${article.excerpt}</p>
                <div class="card-meta">
                    <span class="card-author">Por ${article.author}</span>
                    <time class="card-date">${formatDate(article.date)}</time>
                </div>
            </div>
        </article>
    `).join('');
}

function openArticle(articleId) {
    const article = newsData.find(a => a.id === articleId);
    if (!article) return;
    
    elements.modalBody.innerHTML = `
        <div class="modal-article-header">
            <span class="modal-article-category">${article.category}</span>
            <h1 class="modal-article-title">${article.title}</h1>
            <div class="modal-article-meta">
                <span>Por ${article.author}</span>
                <span>${formatDate(article.date)}</span>
                <span>${article.tags.join(', ')}</span>
            </div>
        </div>
        <img src="${article.image}" alt="${article.title}" class="modal-article-image">
        <div class="modal-article-content">
            ${article.content}
        </div>
        <div class="modal-article-share">
            <span>Compartir:</span>
            <button class="share-btn" onclick="shareArticle('twitter', ${articleId})">
                <i class="fab fa-twitter"></i> Twitter
            </button>
            <button class="share-btn" onclick="shareArticle('linkedin', ${articleId})">
                <i class="fab fa-linkedin"></i> LinkedIn
            </button>
            <button class="share-btn" onclick="shareArticle('facebook', ${articleId})">
                <i class="fab fa-facebook"></i> Facebook
            </button>
        </div>
    `;
    
    elements.articleModal.classList.add('active');
}

function playVideo(videoId) {
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    // In a real application, this would open a video player or redirect to the video
    alert(`Reproduciendo: ${video.title}\n\nEn una implementación real, esto abriría el reproductor de video.`);
}

function shareArticle(platform, articleId) {
    const article = newsData.find(a => a.id === articleId);
    if (!article) return;
    
    const url = `${window.location.origin}#article-${articleId}`;
    const text = `${article.title} - VibeCoding News`;
    
    let shareUrl;
    switch(platform) {
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
            break;
        case 'linkedin':
            shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
            break;
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
            break;
    }
    
    window.open(shareUrl, '_blank', 'width=600,height=400');
}

function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(currentTheme);
}

function setTheme(theme) {
    currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    
    const icon = elements.themeToggle.querySelector('i');
    if (icon) {
        icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }
}

function toggleLanguage() {
    currentLanguage = currentLanguage === 'es' ? 'en' : 'es';
    setLanguage(currentLanguage);
}

function setLanguage(lang) {
    currentLanguage = lang;
    elements.langToggle.textContent = lang.toUpperCase();
    localStorage.setItem('language', lang);
    
    // In a real application, this would update all text content
    // For now, we'll just show a notification
    if (lang === 'en') {
        showNotification('Language changed to English (Demo)', 'info');
    } else {
        showNotification('Idioma cambiado a Español', 'info');
    }
}

function showNewsletterPopup() {
    // Show newsletter popup after 30 seconds if not shown before
    const hasShown = localStorage.getItem('newsletter-shown');
    if (!hasShown) {
        setTimeout(() => {
            elements.newsletterPopup.classList.add('active');
        }, 30000);
    }
}

function handleContactForm(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    
    // Simulate form submission
    showLoading(e.target);
    
    setTimeout(() => {
        hideLoading(e.target);
        showNotification('Mensaje enviado correctamente. Te responderemos pronto.', 'success');
        e.target.reset();
    }, 2000);
}

function handleNewsletterForm(e) {
    e.preventDefault();
    
    const email = e.target.querySelector('input[type="email"]').value;
    
    // Simulate subscription
    showLoading(e.target);
    
    setTimeout(() => {
        hideLoading(e.target);
        showNotification('¡Suscripción exitosa! Recibirás nuestro newsletter semanal.', 'success');
        e.target.reset();
        
        if (elements.newsletterPopup.classList.contains('active')) {
            elements.newsletterPopup.classList.remove('active');
            localStorage.setItem('newsletter-shown', 'true');
        }
    }, 1500);
}

function showLoading(form) {
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    }
}

function hideLoading(form) {
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = submitBtn.textContent.includes('Suscrib') ? 'Suscribirse' : 'Enviar Mensaje';
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add notification styles if not already added
    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 20px;
                background: var(--background);
                border: 1px solid var(--border-color);
                border-radius: 12px;
                padding: 1rem;
                box-shadow: var(--shadow-lg);
                z-index: 5000;
                display: flex;
                align-items: center;
                gap: 0.75rem;
                max-width: 400px;
                animation: slideInRight 0.3s ease-out;
            }
            
            .notification-success { border-left: 4px solid var(--success); }
            .notification-error { border-left: 4px solid var(--error); }
            .notification-info { border-left: 4px solid var(--primary-color); }
            
            .notification button {
                background: none;
                border: none;
                color: var(--text-muted);
                cursor: pointer;
                padding: 0.25rem;
                border-radius: 4px;
                margin-left: auto;
            }
            
            .notification button:hover {
                background: var(--background-secondary);
            }
            
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Global functions for inline event handlers
window.openArticle = openArticle;
window.playVideo = playVideo;
window.shareArticle = shareArticle;

